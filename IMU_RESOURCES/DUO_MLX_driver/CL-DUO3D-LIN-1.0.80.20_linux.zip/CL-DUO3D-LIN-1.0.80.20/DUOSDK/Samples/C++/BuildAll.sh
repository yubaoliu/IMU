#bin/bash
cmake .
make all
